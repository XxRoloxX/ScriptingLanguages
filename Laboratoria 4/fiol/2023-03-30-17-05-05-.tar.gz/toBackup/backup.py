import pprint
from standardInputOutput import *
from pathlib import Path
import subprocess
import datetime
import os
import json


BACKUP_DIR_ENV = "BACKUPS_DIR"
HOME_PATH = "HOME"
DEFAULT_BACKUP_DIR=getEnvironmentVariable("HOME")+os.sep+".backups"
BACKUP_LOGS_FILENAME="backups.json"
ARCHIVE_EXTENSION="tar.gz"
LOGS_DATE_KEY = "Backup date"
LOGS_ARCHIVED_FILES_KEY="Files archvied"
LOGS_NEW_ARCHIVE_LOCATION_KEY="New archive location"

def joinPath(firstPath, secondPath):
    return firstPath+os.sep+secondPath

def getAbsolutePath(path):
    return str(Path(path).absolute())

def getBackupLogFilepath():
    backupDirectory = getBackupDirectoryPath()
    return joinPath(backupDirectory,BACKUP_LOGS_FILENAME)

def getBackupDirectoryPath():

    bdir = getEnvironmentVariable(BACKUP_DIR_ENV)
    return bdir if bdir else DEFAULT_BACKUP_DIR

def getDirectoryToBackupPath():
    path = getArguments()
    return path[0]

def isDirectory(pathToDirectory):
    pathObj = Path(pathToDirectory)
    return pathObj.is_dir()

def isFile(pathToFile):
    pathObj = Path(pathToFile)
    return pathObj.is_file()

def isValidPath(path):
    return Path(path).exists()

def validatePathAsDirectory(pathToDirectory):
    if not isDirectory(pathToDirectory):
        raise Exception("Path is not directory! " + pathToDirectory)
def validatePathExists(pathToFile):
    if not isValidPath(pathToFile):
        raise Exception("Path does not exist! " + str(pathToFile))

def moveFiles(pathFrom, pathTo):

    validatePathExists(pathFrom)

    if(not isValidPath(pathTo) or not isDirectory(pathTo)):
        os.makedirs(pathTo)

    commandLineArguments = ["mv", pathFrom, pathTo ]
    return executeBinary(commandLineArguments)


def executeBinary(arguments):

    return subprocess.Popen(arguments, stdin = subprocess.PIPE, stdout=subprocess.PIPE)

def createTimestamp():
    time:datetime = datetime.datetime.now()
    return time.strftime("%Y-%m-%d-%H-%M-%S")

def createArchiveName(pathToDirectory):
    return createTimestamp()+"-"+str(pathToDirectory.split(os.sep)[-1])+"."+ARCHIVE_EXTENSION


def createArchive(pathToDirectoryToArchive, archiveName):

    validatePathAsDirectory(pathToDirectoryToArchive)
    commandLineArguments = ["tar", "-czvf",archiveName ,pathToDirectoryToArchive]
    return executeBinary(commandLineArguments)

def createArchiveCreationLogs(date, absolutePathOfArchivedFiles, pathOfNewArchive):

    return {
        LOGS_DATE_KEY: str(date),
        LOGS_ARCHIVED_FILES_KEY: str(absolutePathOfArchivedFiles),
        LOGS_NEW_ARCHIVE_LOCATION_KEY:  str(pathOfNewArchive)
    }

def addToBackupLogs(date, absolutePathOfArchivedFiles, pathOfNewArchive):

    backupFolder = getBackupDirectoryPath()
    logsPath = backupFolder+os.sep+BACKUP_LOGS_FILENAME
    currentLogs = list()

    if isFile(logsPath):
        with open(logsPath, "r") as file:
            dataRead = file.read()
            if(len(dataRead)>0):
                try:
                    currentLogs = json.loads(dataRead)
                except Exception:
                    writeToErrorOutput("Incorrect logs format")
                    


    currentLogs.insert(0,createArchiveCreationLogs(date,absolutePathOfArchivedFiles, pathOfNewArchive))

    with open(logsPath,"w") as file:
        file.write(json.dumps(currentLogs))

def createBackupsArchive(pathToDirectoryToArchive):
    archiveName = createArchiveName(pathToDirectoryToArchive)
    createArchive(pathToDirectoryToArchive, archiveName).wait()
    moveFiles(archiveName, getBackupDirectoryPath())
    addToBackupLogs(createTimestamp(), Path(pathToDirectoryToArchive).absolute(), Path(getBackupDirectoryPath()+os.sep+archiveName).absolute())



if __name__=="__main__":
    path  = getDirectoryToBackupPath()
    createBackupsArchive(path)
