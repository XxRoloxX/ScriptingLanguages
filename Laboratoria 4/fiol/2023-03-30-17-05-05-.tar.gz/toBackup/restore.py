import sys
from standardInputOutput import *
from backup import *


def validateArchive(pathToArchive):
    if(not isFile(pathToArchive) or pathToArchive.split(".")[-1]!=ARCHIVE_EXTENSION):
        raise Exception("Incorrect archive filepath!")

def getRestorationPathFromArguments():
    args = getArguments()
    return "." if len(args)==0 else args[0]

def getArchiveToRestoreChoice():
    writeToStandardOutput("Enter archive index to restore")
    index = readFromStandardInput()
    logs = getLogs()
    
    while(type(index)!=int or index<0 or index>=len(logs)):
        writeToStandardOutput("Incorrect index, type again: ")
        index =readFromStandardInput()

    return index


def getLogs():
    backupLogFilepath = getBackupLogFilepath()
    if not isFile(backupLogFilepath):
        raise Exception("No logs file available!")
    
    with open(backupLogFilepath, "r") as logFile:
        logs = json.loads(logFile.read())
    
    return logs

def parseLogsJSON(logs):

    result=""

    for i in range(len(logs)):
        result+="Opcja "+str(i)+"\n"
        result+=formatDictionaryToPrint(logs[i])+"\n\n"

    return result

def unpackArchive(pathToArchvive, pathToUnpack):
    validateArchive(pathToArchvive)

    commandArguments = ["tar", "-xvzf", pathToArchvive, "-C", pathToUnpack]
    return executeBinary(commandArguments)


def emptyDirectory(pathToDirectory):
    validatePathAsDirectory(pathToDirectory)

    commandArguments = ["rm", "-r", pathToDirectory]
    return executeBinary(commandArguments)

def restoreArchive(pathToArchive, restorationPath):
    emptyDirectory(restorationPath).wait()
    unpackArchive(pathToArchive)

def getArchivePathFromLogs(archiveIndex):
    logs = getLogs()
    return logs[archiveIndex][LOGS_NEW_ARCHIVE_LOCATION_KEY]

def showLogs():
    logs =getLogs()
    writeToStandardOutput(parseLogsJSON(logs))
    



if __name__=="__main__":
    restorationPath = getRestorationPathFromArguments()

    showLogs()
